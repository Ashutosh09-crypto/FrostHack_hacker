const express = require('express');
const app = express();
const path = require('path');
const mongoose = require('mongoose');
const participants = require('./models/participant')
const events = require('./models/event')
const requests = require('./models/request')
const cors = require('cors')
const bodyParser = require('body-parser')
const passport = require('passport');
const cookieSession = require('cookie-session');
const flash = require('connect-flash');
const eventsReqs = require('./models/eventsReqs.js')

mongoose.connect('mongodb://localhost:27017/club', { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Database connected");
    })
    .catch(err => {
        console.log("OH NO ERROR!!!");
        console.log(err);
    })


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));


// Google authentication ========================================================================================================================

require('./models/passport');

app.use(cors())
app.use(flash());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

// For an actual app you should configure this with an experation time, better keys, proxy and secure
app.use(cookieSession({
    name: 'tuto-session',
    keys: ['key1', 'key2']
}))

// Auth middleware that checks if the user is logged in
const isLoggedIn = (req, res, next) => {
    if (req.user) {
        next();
    } else {
        // res.sendStatus(401);
        res.redirect('/google');
    }
}

// Initializes passport and passport sessions
app.use(passport.initialize());
app.use(passport.session());

// Example protected and unprotected routes
app.get('/failed', (req, res) => res.send('You Failed to log in!'))

// In this route you can see that if the user is logged in u can acess his info in: req.user

app.get('/good', isLoggedIn, (req, res) => res.send(`Welcome mr ${req.user.displayName}!`));

// Auth Routes
app.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/google/callback', passport.authenticate('google', { failureRedirect: '/failed' }),
    async (req, res) => {
        // Successful authentication, redirect home.


        const isExisting = await participants.findOne({ email: req.user.emails[0].value });
        if (!isExisting) {
            const member = new participants({
                name: req.user.displayName,
                email: req.user.emails[0].value,
                coordinator: false,
                perk: 0,
                league: "bronze",
                club: [],
                achievements: [],
                dp: req.user.photos[0].value
            })

            console.log("new entry created");
            member.save()
                .then(item => {
                    res.send("item saved to database");
                })
                .catch(err => {
                    res.status(400).send("unable to save to database");
                });
        }
        else {
            isExisting.dp = req.user.photos[0].value;
        }


        req.session.user_id = req.user.emails[0].value;

        res.redirect('/');
    }
);

app.get('/logout', (req, res) => {
    req.session = null;
    req.logout();
    res.redirect('/');
})


// Google authentication ========================================================================================================================





// home page

app.get('/', async (req, res) => {

    let member = false;

    if (req.session !== null) {
        const id = req.session.user_id;
        member = await participants.findOne({ email: id });
        // console.log("hello world")
    }

    res.render('landing.ejs', { member });
})







// club page access==

app.get('/club/:clubid', isLoggedIn, async (req, res) => {
    const { clubid } = req.params;
    const members = await participants.find({ club: { $in: [clubid] } });
    let coordinators = [];

    for (let mem of members) {
        if (mem.coordinator[clubid] === true) {
            coordinators.push(mem);
        }
    }

    console.log(coordinators);

    // power is introduced to check whether logged in user is coordinator or not to provide permissions
    let power = false;
    const member = await participants.findOne({ email: req.session.user_id });
    const reqs = await requests.find({ club: clubid });

    console.log(clubid in member.club)
    if (!member.club.includes(clubid)) {
        const newReq = new requests({
            name: member.name,
            email: member.email,
            coordinator: false,
            perk: 0,
            league: "bronze",
            club: clubid,
            achievements: [],
            dp: member.dp
        })

        if (! await requests.findOne({ email: member.email, club: clubid })) {
            newReq.save()
                .then(item => {
                    res.send("Request send successfully");
                })
                .catch(err => {
                    res.status(400).send("unable to save to database");
                });
        } else {
            res.send("Request already sent. Please wait for response by coordinator");
        }
    }
    else {
        if (member.coordinator[clubid] === true) {
            power = true;
        }

        // console.log(power);

        res.render("club", { members, coordinators, power, reqs, clubid });
    }
});


app.use(express.urlencoded({ extended: true }));

app.post('/club/:clubid', isLoggedIn, async (req, res) => {

    const { id } = req.body;
    const { clubid } = req.params;
    const member = await requests.findOne({ email: id, club: clubid });

    const existing = await participants.findOne({ email: id });

    if (req.body.action === 'accept') {
        existing.club.push(member.club);
        await existing.save();
        await requests.findByIdAndDelete(member._id);
    } else if (req.body.action === 'reject') {
        await requests.findByIdAndDelete(member._id);
        // console.log("deleted");
    }

    res.redirect(`/club/${clubid}`)
})


app.get('/club/:clubid/details/:id', isLoggedIn, async (req, res) => {
    const { clubid, id } = req.params;

    const user = await participants.findOne({ email: req.session.user_id });

    const mem = await participants.findOne({ email: id });


    const power = user.coordinator[clubid];

    // this is to check for self permission.. i,e. leaving any club
    const currentUser = req.session.user_id;
    res.render('details.ejs', { mem, clubid, power, user });
});



// request for removing any member from club

app.post('/club/:clubid/details/:id', isLoggedIn, async (req, res) => {
    const { clubid, id } = req.params;


    const member = await participants.findOne({ email: id });

    if (req.body.action === 'leave') {
        const index = member.club.indexOf(clubid);
        if (index > -1) {
            member.club.splice(index, 1);

        }
        await member.save();
        res.redirect('/')
    } else if (req.body.action === 'addAch') {

        const place = req.body.place;
        const eventName = req.body.eventName;
        const perks = req.body.perks;
        const price = { pl: place, event: eventName, club: clubid, perk: perks };
        member.achievements.push(price);
        member.perk += parseInt(perks);
        await member.save();

        res.redirect(`/club/${clubid}/details/${id}`);
    }
    else if (req.body.action === 'giveCoord') {
        member.coordinator[clubid] = !member.coordinator[clubid];
        await member.save();
        res.redirect(`/club/${clubid}/details/${id}`);
    }
    else if (req.body.action === 'giveAdmin') {
        member.admin = true;
        await member.save();
        res.redirect(`/club/${clubid}/details/${id}`);
    }
    else {

        const index = member.club.indexOf(clubid);
        if (index > -1) {
            member.club.splice(index, 1);

        }
        member.admin = false;
        await member.save();
        res.redirect(`/club/${clubid}`)
    }
})

app.post('/club/:clubid/details', async (req, res) => {
    let id = req.body.email;
    const { clubid } = req.params;

    if (id.length === 6) {
        id = id.toLowerCase();
        id = id + "@students.iitmandi.ac.in";
    }

    const user = await participants.findOne({ email: id, club: { $in: [clubid] } });


    if (user !== null) {

        res.redirect(`/club/${clubid}/details/${id}`);
    }
    else {

        res.send("Sorry, no user by this name. Note: search is case sensitive.");
    }
})




app.post('/club/:clubid/details/:id/:eventName/:place', isLoggedIn, async (req, res) => {
    const { eventName, place, id, clubid } = req.params;

    const member = await participants.findOne({ email: id });
    const achs = member.achievements;

    let index = -1;
    let count = 0;
    for (let ac of achs) {
        if (ac.pl === place && ac.event === eventName) {
            member.perk -= parseInt(ac.perk);
            index = count;
        }
        count++;
    }


    if (index > -1) {

        member.achievements.splice(index, 1);

        console.log("remove");
    }

    await member.save();

    res.redirect(`/club/${clubid}/details/${id}`);
});


app.get('/host', isLoggedIn, (req, res) => {
    // res.sendFile('C:/Users/Ashutosh Purohit/Desktop/ClubProj/views/host.html');
    res.render('host.ejs');
})

app.get('/events/future', isLoggedIn, async (req, res) => {
    const allEvents = await events.find({});
    const reqs = await eventsReqs.find({});
    console.log(allEvents);
    let power = false;

    if (req.session !== null) {
        const id = req.session.user_id;
        const member = await participants.findOne({ email: id });
        power = member.admin;
    }

    res.render("events.ejs", { power, reqs, allEvents, messages: req.flash('EventAdded') });
})

// app.get('/registerEvent', isLoggedIn, (req, res) => {
//     const { eventName } = req.params;
//     res.render("login.ejs", { team: true, create: false })
// })

app.post('/registerEvent', isLoggedIn, async (req, res) => {
    const { eventName } = req.body;
    const event = await events.findOne({ name: eventName });
    console.log(event);
    let team = false;
    if (event.typeOf === 'team') {
        team = true;
    }
    let create = false;
    if (req.body.action === 'create') {
        create = true;
    }

    res.render("login.ejs", { team, create, event });
})

function splitDate(date) {
    parts = date.split('T');
    // console.log(parts);
    dates = parts[0].split('-');
    times = parts[1].split(':');
    return new Date(parseInt(dates[0]), parseInt(dates[1]) - 1, parseInt(dates[2]), parseInt(times[0]), parseInt(times[1]));
}


app.post('/host', async (req, res) => {
    const { eventName, description, type, start, end, organizerName, organizerEmail, organizerPhone, prizes, documentation, poster, venue, why, seats, schedule, onelineDescription } = req.body;

    startDate = splitDate(start);
    endDate = splitDate(end);

    const isExist = await events.find({ name: eventName });
    if (isExist.length === 0) {
        const event = new eventsReqs({
            name: eventName,
            description: description,
            typeOf: type,
            start: startDate,
            end: endDate,
            organizerEmail: organizerEmail,
            organizerName: organizerName,
            organizerPhone: organizerPhone,
            prizes: prizes,
            documentation: documentation,
            eventPoster: poster,
            venue: venue
        })

        const isReq = await eventsReqs.find({ name: eventName });

        if (isReq.length > 0) {
            res.send("Please don't spam. Wait for the admins to accept the host request!")
        } else {
            await event.save();
            req.flash('EventAdded', 'Event successfully added');
            res.redirect('/events/future');
        }
    } else {
        req.flash('EventAdded', 'Event already existed with this name. Try again!');
        res.redirect('/events/future');
    }
})

app.post('/eventHost/:eventName', async (req, res) => {
    const { eventName } = req.params;
    const reqEvent = await eventsReqs.findOne({ name: eventName });

    if (req.body.action === 'accept') {
        const { name, description, typeOf, start, end, organizerName, organizerEmail, organizerPhone, prizes, documentation, eventPoster, venue, why, seats, schedule, onelineDescription } = reqEvent;
        const newEvent = new events({
            name: name,
            description: description,
            typeOf: typeOf,
            start: start,
            end: end,
            organizerEmail: organizerEmail,
            organizerName: organizerName,
            organizerPhone: organizerPhone,
            prizes: prizes,
            documentation: documentation,
            eventPoster: eventPoster,
            venue: venue,
            why: why,
            seats: seats,
            schedule: schedule,
            onlineDescription: onelineDescription
        });

        await newEvent.save();

    }

    await eventsReqs.deleteOne({ name: eventName });
    res.redirect('/futureEvents');
});

app.get('/:eventName', async (req, res) => {
    const { eventName } = req.params;
    console.log(eventName);
    const event = await events.findOne({ name: eventName });

    console.log(eventName);
    let power = false;

    if (req.session !== null) {
        const id = req.session.user_id;
        const member = await participants.findOne({ email: id });
        // const mail = event.organizerEmail;

        // let isOrg = (id === mail);
        power = (member.admin);
    }

    res.render('eventProfile.ejs', { event, power });
})


app.get('/events/running', async (req, res) => {
    const dateNow = new Date().getTime();
    const allEvents = await events.find({})
    let running = [];

    for (let event of allEvents) {
        if (event.start.getTime() <= dateNow && event.end.getTime() > dateNow) {
            running.push(event);
        }

    }
    res.render('currentEvents.ejs', { running });
})


app.post('/eventRegister', isLoggedIn, async (req, res) => {
    const { teamName, email, username, password, create, eventName } = req.body;
    const event = await events.findOne({ name: eventName });

    if (teamName && create) {
        for (let part of event.participants) {
            if (part.team === teamName) {
                res.send('Team name already exists');
            }
        }
        await event.participants.push({ team: teamName, teamMembers: [email], pass: password })
        await event.save();
    }
    else if (teamName && create) {
        let foundTeam = {};
        let count = 0;
        for (let part of event.participants) {
            if (part.team === teamName) {
                foundTeam = part;
                break;
            }
            count++;
        }
        if (foundTeam === {}) {
            res.send('No team found with this name. Please try again!');
        }
        else if (password === part.pass) {
            await event.participants[count].teamMembers.push(email);
        }
        else {
            res.send("Invalid Password!");
        }

        await event.save();
    }
    else {
        event.participants.push({ name: username, email: email });
        await event.save();
    }


    res.redirect('/');
})

app.post('/addMem', isLoggedIn, async (req, res) => {
    const { eventName } = req.body;
    const event = await events.findOne({ name: eventName });

    let sponReq = false;
    if (req.body.action === "sponser") {
        sponReq = true;
    }
    res.render('addSponMem.ejs', { event, sponReq });
})

app.post('/addMem/submitMem', isLoggedIn, async (req, res) => {
    const { eventName, username, email, role } = req.body;
    const event = await events.findOne({ name: eventName });

    event.members.push({ name: username, email: email, role: role });
    await event.save();

    const url = '/' + event.name;
    res.redirect(url);

})

app.post('/addMem/submitSpon', isLoggedIn, async (req, res) => {
    const { eventName, sponName } = req.body;
    const event = await events.findOne({ name: eventName });

    event.sponsors.push(sponName);
    await event.save();
    const url = '/' + event.name;
    res.redirect(url);

})



app.listen(3000, () => {
    console.log("STARTED");
})


