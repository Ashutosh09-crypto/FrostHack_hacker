const mongoose = require('mongoose');

const eventsSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    onelineDescription: {
        type: String
    },
    typeOf:
    {
        type: String,
        required: true
    }
    ,
    start: {
        type: Date
    },
    end: {
        type: Date
    },
    why: {
        type: [String]
    },
    seats: {
        type: Number
    },
    schedule: {
        type: [Object]
    },
    eventPhotos: {
        type: [String]
    },
    sponsors: {
        type: [String]
    },
    members: {
        type: [Object]
    }
    ,
    organizerName: {
        type: String
    },
    organizerEmail: {
        type: String
    },
    organizerPhone: {
        type: String
    },
    prizes: {
        type: [String]
    },
    documentation: {
        type: String
    },
    eventPoster: {
        type: String
    },
    venue: {
        type: String
    },
    positions: {
        type: [Object]

    },
    participants: {
        type: [Object]
    }
})

const events = mongoose.model('events', eventsSchema);

module.exports = events;