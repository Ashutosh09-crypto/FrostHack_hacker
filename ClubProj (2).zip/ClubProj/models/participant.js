const mongoose = require('mongoose');

const participantsSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    coordinator:
    {
        technical: { type: Boolean, default: false }, cultural: { type: Boolean, default: false }, robotronics: { type: Boolean, default: false },
        stac: { type: Boolean, default: false }, yantrik: { type: Boolean, default: false },
        nirman: { type: Boolean, default: false }, "sae": { type: Boolean, default: false },
        eCell: { type: Boolean, default: false }, music: { type: Boolean, default: false },
        dance: { type: Boolean, default: false }, drama: { type: Boolean, default: false },
        art: { type: Boolean, default: false }, pmc: { type: Boolean, default: false },
        movie: { type: Boolean, default: false }, designauts: { type: Boolean, default: false }
    }
    ,
    perk: {
        type: Number,
        default: 0
    },
    league: {
        type: String,
        default: "Bronze"
    }
    ,
    club: {
        type: [String]
    },
    achievements: {
        type: [],
        default: []
    },
    dp: {
        type: String
    },
    admin: {
        type: Boolean,
        default: false
    }
})

const participants = mongoose.model('participants', participantsSchema);

module.exports = participants;