const mongoose = require('mongoose');

const reqSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    coordinator: {
        type: Boolean,
        default: false
    },
    perk: {
        type: Number,
        default: 0
    },
    league: {
        type: String,
        default: "Bronze"
    }
    ,
    club: {
        type: String,
        required: true
    },
    achievements: {
        type: [String]
    },
    dp: {
        type: String
    }
})

const requests = mongoose.model('requests', reqSchema);

module.exports = requests;