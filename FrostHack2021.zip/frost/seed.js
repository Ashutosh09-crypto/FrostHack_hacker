const participants = require('./models/participant')
const requests = require('./models/request')
const mongoose = require('mongoose');


mongoose.connect('mongodb://localhost:27017/club', { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Database connected");
    })
    .catch(err => {
        console.log("OH NO ERROR!!!");
        console.log(err);
    })

const eagle = new participants({
    name: "Ashutosh Purohit",
    email: "b20086@students.iitmandi.ac.in",
    coordinator: {
        technical: true, cultural: true, robotronics: true,
        stac: true, yantrik: true,
        nirman: true, "sae": true,
        eCell: true, music: true,
        dance: true, drama: true,
        art: true, pmc: true,
        movie: true, designauts: true
    },
    perk: 10,
    league: "gold",
    club: ["technical", "cultural", "robotronics", "stac", "yantrik", "nirman", "sae", "eCell", "music", "dance", "drama", "art", "pmc", "movie", "designauts"],
    dp: "https://lh3.googleusercontent.com/a-/AOh14GhGBtSBczm9K-DP5F-fc2yG2cjCYztGlfwe2AmG=s96-c",
    achievements: [],
    admin: true
})

// extra attribute of profile picture to be added here


const func = async () => {

    eagle.save();


}


func();









