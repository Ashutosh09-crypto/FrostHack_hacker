const mandrill = require('node-mandrill')('"506214132660-mliv5n4ubnguo4gbq355lgerpojiaeai.apps.googleusercontent.com"');

function sendEmail(_name, _email, _subject, _message) {
    mandrill('/messages/send', {
        message: {
            to: [{ email: _email, name: _name }],
            from_email: 'noreply@yourdomain.com',
            subject: _subject,
            text: _message
        }
    }, function (error, response) {
        if (error) console.log(error);
        else console.log(response);
    });
}

sendEmail("Ashutosh Purohit", "purohitashutosh987@gmail.com", "Testing", "Hello there, what's up!");

// define your own email api which points to your server.

