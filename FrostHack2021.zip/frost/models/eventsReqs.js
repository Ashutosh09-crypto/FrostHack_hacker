const mongoose = require('mongoose');

const eventsReqSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    typeOf:
    {
        type: String,
        required: true
    }
    ,
    start: {
        type: Date
    },
    end: {
        type: Date
    }
    ,
    organizerName: {
        type: String
    },
    organizerEmail: {
        type: String
    },
    organizerPhone: {
        type: String
    },
    prizes: {
        type: String
    },
    documentation: {
        type: String
    },
    eventPoster: {
        type: String
    },
    venue: {
        type: String
    }
})

const eventsReqs = mongoose.model('eventsReqs', eventsReqSchema);

module.exports = eventsReqs;